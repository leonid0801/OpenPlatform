<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8"/>
		<meta content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" >
		<meta name="apple-mobile-web-app-capable" content="yes" />
		<meta name="format-detection" content="telephone=no, email=no">
		<title>梧桐下漫步</title>
		<!-- http://mat1.gtimg.com/auto/css/car2013/wx/base.css -->
		<!--<link rel="stylesheet" type="text/css" href="http://mat1.gtimg.com/auto/css/car2013/wx/base.css">-->
		<link rel="stylesheet" type="text/css" href="/application/view/templates/css/style.css">
		<script>document.domain = 'sinaapp.com';var WXDEALER_CONFIG={uin:'',token:'',index:'',version:''};</script>
	</head>	
