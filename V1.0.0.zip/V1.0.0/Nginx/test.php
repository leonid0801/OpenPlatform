<?php

phpinfo();
 
?>